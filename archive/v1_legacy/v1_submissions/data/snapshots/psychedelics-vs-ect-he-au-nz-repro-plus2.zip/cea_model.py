# See earlier chat for full comments
import pandas as pd, numpy as np
params = pd.read_csv("parameters_psa.csv")
clin = pd.read_csv("clinical_inputs.csv")
cost_au = pd.read_csv("cost_inputs_au.csv")

def get_param(name, default=None):
    row = params[params["Parameter"]==name]
    return float(row["BaseValue"].iloc[0]) if not row.empty else default

def cost_lookup_au(label):
    row = cost_au[cost_au["Item"]==label]
    return float(row["AUD_Value_2024"].iloc[0]) if not row.empty else 0.0

utility_dep = get_param("Utility depressed", 0.57)
utility_rem = get_param("Utility remission", 0.81)
cost_ect_session = cost_lookup_au("ECT total session cost (public)")
cost_ket_session = cost_lookup_au("Ketamine total session (IV)")
cost_esk_session = cost_lookup_au("Esketamine session – assumed total")
cost_psilo_program = cost_lookup_au("Psilocybin program (2-dose + therapy)")

def simulate_strategy(strategy="ECT", horizon_months=60, cohort=1000):
    dep, rem = cohort, 0.0
    total_cost, total_qalys = 0.0, 0.0
    if strategy=="ECT": total_cost += 8*cost_ect_session; p_remit=0.60
    elif strategy=="Ketamine": total_cost += 8*cost_ket_session; p_remit=0.45
    elif strategy=="Esketamine": total_cost += 8*cost_esk_session; p_remit=0.36
    elif strategy=="Psilocybin": total_cost += cost_psilo_program; p_remit=0.30
    else: p_remit=0.0
    rem = dep*p_remit; dep -= rem
    for m in range(1, horizon_months+1):
        total_qalys += (dep*utility_dep + rem*utility_rem)/cohort/12.0
    return {"strategy":strategy,"cost":total_cost,"qalys":total_qalys}

if __name__=="__main__":
    for s in ["ECT","Ketamine","Esketamine","Psilocybin"]:
        print(simulate_strategy(s))
