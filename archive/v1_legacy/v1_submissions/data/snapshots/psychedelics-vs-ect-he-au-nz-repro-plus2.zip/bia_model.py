import pandas as pd
cost_au = pd.read_csv("cost_inputs_au.csv")
def get(cost_table, item):
    row = cost_table[cost_table["Item"]==item]
    return float(row.iloc[0,1]) if not row.empty else 0.0
def bia_5y(ect_patients=3000, uptake_ket=[0.05,0.10,0.15,0.20,0.25], uptake_psi=[0.01,0.03,0.06,0.08,0.10]):
    c_ect = get(cost_au,"ECT total session cost (public)")*8
    c_ket = get(cost_au,"Ketamine total session (IV)")*12
    c_psi = get(cost_au,"Psilocybin program (2-dose + therapy)")
    out=[]
    for y in range(5):
        ect_share = 1 - uptake_ket[y] - uptake_psi[y]
        ect_n = int(ect_patients*ect_share)
        ket_n = int(ect_patients*uptake_ket[y])
        psi_n = int(ect_patients*uptake_psi[y])
        baseline = ect_patients*c_ect
        scenario = ect_n*c_ect + ket_n*c_ket + psi_n*c_psi
        out.append({"year":y+1,"baseline_cost":baseline,"scenario_cost":scenario,"net_impact":scenario-baseline,
                    "ECT_patients":ect_n,"Ket_patients":ket_n,"Psi_patients":psi_n})
    return pd.DataFrame(out)
if __name__=="__main__":
    print(bia_5y())
