"""
PSA-enabled CEA for Psychedelics vs ECT (AU/NZ)
- Samples parameters from `parameters_psa.csv` using Distribution column (e.g., Beta(36,24), Gamma(sd=200))
- Uses a simplified cohort model (see cea_model.py); extend for decision-grade work.
Outputs:
- psa_results.csv (per-iteration costs & QALYs)
- ceac.png (cost-effectiveness acceptability curve)
"""
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import re

PARAMS_CSV = "parameters_psa.csv"
COSTS_AU = "cost_inputs_au.csv"

def parse_dist(dist_str, mean):
    """Return sampler function given dist string and mean (from BaseValue)."""
    if pd.isna(dist_str) or dist_str=="" or str(dist_str).lower()=="fixed":
        return lambda n: np.full(n, mean)
    m = re.match(r"Beta\((\d+\.?\d*),\s*(\d+\.?\d*)\)", dist_str, re.I)
    if m:
        a=float(m.group(1)); b=float(m.group(2))
        return lambda n: np.random.beta(a,b,size=n)
    m = re.match(r"Gamma\(\s*sd\s*=\s*(\d+\.?\d*)\s*\)", dist_str, re.I)
    if m:
        sd=float(m.group(1)); mu=float(mean)
        k=(mu/sd)**2; theta=sd**2/mu
        return lambda n: np.random.gamma(shape=k, scale=theta, size=n)
    m = re.match(r"Normal\(\s*sd\s*=\s*(\d+\.?\d*)\s*\)", dist_str, re.I)
    if m:
        sd=float(m.group(1)); mu=float(mean)
        return lambda n: np.random.normal(mu, sd, size=n)
    m = re.match(r"Lognormal\(\s*gsd\s*=\s*(\d+\.?\d*)\s*\)", dist_str, re.I)
    if m:
        gsd=float(m.group(1)); mu=float(mean)
        # approximate: set sigma via gsd, derive mu_log from mean
        sigma=np.log(gsd); mu_log=np.log(mu) - 0.5*sigma**2
        return lambda n: np.random.lognormal(mean=mu_log, sigma=sigma, size=n)
    # default fixed
    return lambda n: np.full(n, mean)

def load_tables():
    params = pd.read_csv(PARAMS_CSV)
    costs = pd.read_csv(COSTS_AU)
    return params, costs

def get_cost(costs, item):
    row = costs[costs["Item"]==item]
    return float(row["AUD_Value_2024"].iloc[0]) if not row.empty else 0.0

def simulate_once(draw, costs):
    """Return dict of outcomes for each strategy (cost, qaly). Very simplified."""
    util_dep = draw("Utility depressed")
    util_rem = draw("Utility remission")
    # remission probs
    p_remit = {
        "ECT": draw("ECT remission"),
        "Ketamine": draw("Ketamine remission (4w)"),
        "Esketamine": draw("Esketamine remission (4w)"),
        "Psilocybin": draw("Psilocybin remission")
    }
    # costs
    cost_ect = 8*get_cost(costs, "ECT total session cost (public)")
    cost_ket = 8*get_cost(costs, "Ketamine total session (IV)")
    cost_esk = 8*get_cost(costs, "Esketamine session – assumed total")
    cost_psi = get_cost(costs, "Psilocybin program (2-dose + therapy)")

    # single-cycle-like simplification over 5y horizon for QALYs
    cohort = 1.0
    horizon_yrs = 5.0

    results = {}
    for s, cost_ind in [("ECT", cost_ect), ("Ketamine", cost_ket), ("Esketamine", cost_esk), ("Psilocybin", cost_psi)]:
        rem = cohort * p_remit[s]
        dep = cohort - rem
        qalys = (dep*util_dep + rem*util_rem) * horizon_yrs  # crude
        results[s] = {"cost": cost_ind, "qalys": qalys}
    return results

def main(N=2000, wtp=50000):
    params, costs = load_tables()
    # build samplers
    samplers = {}
    for _,r in params.iterrows():
        name=r["Parameter"]; mean=float(r["BaseValue"]); dist=r["Distribution"]
        samplers[name]=parse_dist(dist, mean)
    def draw(name):
        return samplers[name](1)[0] if name in samplers else np.nan

    records = []
    for i in range(N):
        res = simulate_once(draw, costs)
        # Incremental vs ECT
        for s in ["Ketamine","Esketamine","Psilocybin"]:
            dcost = res[s]["cost"] - res["ECT"]["cost"]
            dq = res[s]["qalys"] - res["ECT"]["qalys"]
            nmb = dq*wtp - dcost
            records.append({"iter":i+1,"strategy":s,"cost":res[s]["cost"],"qalys":res[s]["qalys"],
                            "inc_cost":dcost,"inc_qalys":dq,"nmb":nmb})
    df = pd.DataFrame(records)
    df.to_csv("psa_results.csv", index=False)

    # CEAC: probability of cost-effectiveness by WTP for each strategy vs ECT
    wtp_grid = np.linspace(0, 100000, 101)
    ceac = []
    for s in ["Ketamine","Esketamine","Psilocybin"]:
        df_s = df[df["strategy"]==s]
        for w in wtp_grid:
            p = (df_s["inc_qalys"]*w - df_s["inc_cost"] > 0).mean()
            ceac.append({"strategy":s,"wtp":w,"prob_ce":p})
    ceac = pd.DataFrame(ceac)
    ceac.to_csv("ceac.csv", index=False)

    # Plot CEAC
    fig, ax = plt.subplots(figsize=(7,4))
    for s in ["Ketamine","Esketamine","Psilocybin"]:
        sub = ceac[ceac["strategy"]==s]
        ax.plot(sub["wtp"], sub["prob_ce"], label=s)
    ax.set_xlabel("WTP (AUD per QALY)")
    ax.set_ylabel("Probability cost-effective vs ECT")
    ax.set_ylim(0,1)
    ax.legend()
    fig.tight_layout()
    fig.savefig("ceac.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("Saved psa_results.csv and ceac.png")

if __name__ == "__main__":
    main()
