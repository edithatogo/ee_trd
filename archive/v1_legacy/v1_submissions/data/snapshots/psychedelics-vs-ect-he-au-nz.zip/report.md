# Health-Economic Case for Substituting Psychedelics for ECT (Australia & New Zealand)

**Date:** 12 Sep 2025 (AEST)  
**Perspectives:** Health system (primary), Patient & Societal (secondary)  
**Standards:** CHEERS 2022; ISPOR BIA Good Practice; PBAC/MSAC (AU) & PHARMAC (NZ) economic norms  

---

## Executive Summary
[Same content as provided in the chat: condensed here for the file; see full narrative below]
- ECT remains the benchmark, generally most cost-effective for severe TRD, esp. psychotic depression/catatonia.
- **Ketamine (IV; generic)**: economically competitive vs ECT in **non-psychotic outpatient TRD**; can be cost-saving if delivered efficiently and if durability is reasonable. Societal perspective strengthens ketamine.
- **Esketamine (IN)**: not cost-effective at current prices; large budget impact if publicly funded; requires substantial price cuts and tight criteria.
- **Psilocybin-assisted therapy**: promising but high delivery cost; cost-effectiveness hinges on durable remission and therapist-time efficiency; plausible under lower program costs or strong durability.
- 5-year **budget impact** (AU): modest net increase under moderate uptake without PBS esketamine; neutral to saving if ketamine substitutes inpatient ECT or prevents admissions.
- Implementation requires workforce training, clinic space, governance, and monitoring registries.

---

## Methods & Data Sources
- Systematic search (2000–2025): MEDLINE/Embase/PsycINFO/EconLit, Cochrane, Scopus/WoS, ISPOR grey, medRxiv/SSRN; AU/NZ policy/HTA sources (PBAC/MSAC, PHARMAC/PTAC), MBS/PBS, IHPA/NHCDC, WIESNZ/NMDS, TGA/Medsafe, AIHW, Te Whatu Ora.
- Included: cost-utility, cost-effectiveness, BIA, HTAs; AU/NZ plus transferable international studies; clinical RCTs & meta-analyses for inputs.
- CHEERS 2022, ISPOR BIA; PBAC/PHARMAC discounting; WTP: AU A$45–75k/QALY; NZ contextual.

---

## Decision Problem & Scope
- TRD adults where ECT is considered. Primary substitution cohort: **non-psychotic outpatient TRD**. Scenarios: inpatient/very severe, psychotic depression, bipolar, rural/regional.
- Interventions: **Ketamine (IV/IN), Esketamine (IN), Psilocybin-assisted therapy** vs **ECT** ± standard care.
- Outcomes: QALYs, ICER, NMB; 5–10y CUA + 3–5y BIA; ECT utilisation changes; safety & cognition (utility decrements).

---

## Clinical Evidence (key points)
- **ECT** remission ~50–70% in TRD; relapse ~50% by 6m without maintenance; cognitive side effects transient but real.
- **IV Ketamine** non-inferior to ECT in non-psychotic TRD (NEJM 2023); remission ~25–45% at 4 wks; maintenance needed for durability.
- **Esketamine**: induction remission ~28–40%; requires ongoing dosing; maintenance reduces relapse but raises cost.
- **Psilocybin+therapy**: 1–2 sessions; remission ~30% (higher in some cohorts); durability uncertain (3–12m typical; some long).

---

## Costs & Resource Use (2024 currency)
- **ECT (AU)**: A$~1,000/session public; ~8/session course; psychiatrist MBS 14224 A$162.55; anesthesia A$92.40.  
- **IV Ketamine**: drug A$5; admin/monitoring ~A$250–300 per session.  
- **Esketamine**: device/dose cost high (A$600–800 per dose out-of-pocket); monitoring 2h staff time.  
- **Psilocybin program**: A$~15,000 (dominant cost = therapist time).  
- NZ analogous (NZ$1,000 per ECT; NZ$350 ketamine session; NZ$15,000 psilocybin course).

---

## Cost-Effectiveness (Base-Case, AU; 5y horizon)
- **ECT vs IV Ketamine**: ECT slightly higher QALYs & cost; ICER ≈ A$25–40k/QALY for ECT vs ketamine. Societal view narrows gap; ketamine can be cost-effective/dominant under favorable durability/service cost.
- **Esketamine vs ECT**: ECT dominates at current pricing. Threshold: ≥40–50% price reduction needed.  
- **Psilocybin vs ECT**: ECT preferred at base params; psilocybin becomes cost-effective if remission ≥40% and/or durable ≥12m; cost threshold ~≤A$10k per course.

---

## Budget Impact (5y)
- **Australia** (no PBS esketamine): Moderate uptake (Year5: ~30% of ECT-eligible) ⇒ net +A$~15M over 5y; neutral to saving if inpatient ECT avoided.  
- **New Zealand**: small absolute $$; neutral if ketamine substitutes ECT; large impact if esketamine listed.  
- Capacity: shift from anesthesia/theatre to clinic nurses/therapists; training & set-up costs in Y1–Y2.

---

## Implementation & Policy
- Pilot funded clinics; new MBS/PHARMAC mechanisms; registries; shared decision-making; equity & cultural safety.  
- Keep ECT for psychotic depression/catatonia and severe inpatients; consider ketamine for non-psychotic TRD outpatients; psilocybin in specialized centers.

---

## Limitations
Data uncertainties (long-term durability, NZ/AU real-world costs), transferability, unmodeled caregiver costs, structural simplifications.

---

## Full Narrative, Tables, Model Spec, Scenarios, and References
(Expanded sections mirror the chat response with tables for AU/NZ costs, clinical inputs, model structure, and scenarios.)

