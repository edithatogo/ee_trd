# References (Selected & Cited)

1. Anand A, et al. Ketamine vs Electroconvulsive Therapy for Nonpsychotic Treatment-Resistant Major Depression. N Engl J Med. 2023;388:2315–2325.
2. Frederiksen SO, et al. Cost-utility analysis of esketamine vs ECT in TRD (NHS perspective). BMC Psychiatry. 2021;21:427.
3. Chatterton ML, et al. Economic evaluation of subcutaneous ketamine for TRD (KADS RCT). J Affect Disord. 2025;387:119502.
4. PBAC Public Summary Documents (2021–2024): Esketamine (Spravato) for TRD. Australian Government, Department of Health.
5. PHARMAC PTAC Minutes (Feb 2020): Esketamine for TRD (New Zealand).
6. ICER (US). Esketamine for Treatment-Resistant Depression: Evidence Report and Meeting Summary. 2020–2022.
7. UNSW News (2023). Why low-cost ketamine is still inaccessible in Australia.
8. RNZ News (2025). NZ’s first authorised prescriber hopes psilocybin therapy becomes more available.
9. The Guardian (2024). Australia’s first psychedelic therapy clinic opens (program cost report).
10. RANZCP/APA ECT guidelines and cognitive outcomes literature (various).
11. SUSTAIN-1 & TRANSFORM trials for esketamine efficacy and relapse (Janssen program, multiple journals).
12. MBS schedule (2024): Items 14224, 20104, etc.; IHPA/NHCDC cost reports; AR-DRG references.
13. Te Whatu Ora pricing/casemix (WIESNZ), NMDS; Pharmac Schedule (NZ).

*Note:* Where precise bibliographic details are needed (e.g., DOI), please supplement via database export; many policy sources are web documents with changing URLs.
