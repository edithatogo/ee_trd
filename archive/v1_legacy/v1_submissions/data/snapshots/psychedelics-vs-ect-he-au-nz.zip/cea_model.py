"""
CEA Model Skeleton: Psychedelics (Ketamine, Esketamine, Psilocybin) vs ECT in TRD
- Reads parameters from CSVs generated alongside this file.
- Implements a simple 3-state Markov model (Depressed, Remission, Dead) with monthly cycles.
- This is a template to be adapted; numbers are placeholders from the parameter CSVs.
"""

import pandas as pd
import numpy as np

# Load parameter tables
params = pd.read_csv("parameters_psa.csv")
clin = pd.read_csv("clinical_inputs.csv")
cost_au = pd.read_csv("cost_inputs_au.csv")
cost_nz = pd.read_csv("cost_inputs_nz.csv")

def get_param(name, default=None):
    row = params[params["Parameter"]==name]
    if row.empty:
        return default
    return float(row["BaseValue"].iloc[0])

# Base values
discount_au = get_param("Discount rate (AU)", 0.05)
utility_dep = get_param("Utility depressed", 0.57)
utility_rem = get_param("Utility remission", 0.81)

# Costs (AU) helpers
def cost_lookup_au(label):
    row = cost_au[cost_au["Item"]==label]
    return float(row["AUD_Value_2024"].iloc[0]) if not row.empty else 0.0

cost_ect_session = cost_lookup_au("ECT total session cost (public)")
cost_ket_session = cost_lookup_au("Ketamine total session (IV)")
cost_esket_session = cost_lookup_au("Esketamine session – assumed total")
cost_psilo_program = cost_lookup_au("Psilocybin program (2-dose + therapy)")

# Clinical probabilities
ect_rem = get_param("ECT remission", 0.60)
ket_rem = get_param("Ketamine remission (4w)", 0.45)
esk_rem = get_param("Esketamine remission (4w)", 0.36)
psi_rem = get_param("Psilocybin remission", 0.30)

# Simplified monthly relapse rates (illustrative only)
relapse_ect_month = 1 - np.power(1-0.5, 1/6)  # ~50% by 6 months
relapse_maint_month = 1 - np.power(1-0.267, 1/4)  # ~26.7% in 4 months
relapse_off_month = 1 - np.power(1-0.6, 1/12)  # ~60%/yr

def simulate_strategy(strategy="ECT", horizon_months=60, cohort=1000, country="AU"):
    """
    Very simplified cohort model:
    - Month 0-3: induction; apply remission probability at end of month 1
    - Thereafter: remission can relapse monthly; depressed can (rarely) remit (ignored here for simplicity)
    - Costs: induction costs + maintenance illustrative
    """
    # Initial cohort all depressed
    dep = cohort
    rem = 0
    dead = 0

    # Costs & QALYs accumulators
    total_cost = 0.0
    total_qalys = 0.0

    # Induction costs
    if strategy == "ECT":
        total_cost += cost_ect_session * 8  # 8 sessions
        p_remit = ect_rem
    elif strategy == "Ketamine":
        total_cost += cost_ket_session * 8
        p_remit = ket_rem
    elif strategy == "Esketamine":
        total_cost += cost_esket_session * 8
        p_remit = esk_rem
    elif strategy == "Psilocybin":
        total_cost += cost_psilo_program
        p_remit = psi_rem
    else:
        p_remit = 0.0

    # Apply remission at end of induction
    rem = dep * p_remit
    dep = dep - rem

    # Monthly cycles (utilities only; minimal additional costs here)
    for m in range(1, horizon_months+1):
        # utilities
        total_qalys += (dep * utility_dep + rem * utility_rem) / cohort / 12.0

        # Relapse from remission (simple)
        if strategy in ["Esketamine", "Ketamine"] and m<=4:
            p_rel = relapse_maint_month
        else:
            p_rel = relapse_ect_month if strategy=="ECT" else relapse_off_month

        relapses = rem * p_rel
        rem -= relapses
        dep += relapses

    return {"strategy":strategy, "cost": total_cost, "qalys": total_qalys}

if __name__ == "__main__":
    for s in ["ECT","Ketamine","Esketamine","Psilocybin"]:
        res = simulate_strategy(strategy=s)
        print(s, res)
