# Search Log & PRISMA-style Record
**Timestamp (AEST):** 2025-09-12T13:28:03

## Databases & Registers
MEDLINE/PubMed, Embase, PsycINFO, EconLit, Cochrane CENTRAL, Scopus, Web of Science, medRxiv/SSRN, ClinicalTrials.gov, ANZCTR, WHO ICTRP, PBAC/MSAC docs, PHARMAC/PTAC minutes, MBS/PBS, IHPA/NHCDC, WIESNZ/NMDS, TGA/Medsafe, AIHW, Te Whatu Ora.

## Core Boolean Seeds
1. `(ketamine OR esketamine OR psilocybin OR "psychedelic-assisted") AND (electroconvulsive OR ECT) AND (cost* OR economic OR cost-effectiveness OR budget impact OR ICER OR QALY)`  
2. `(Australia OR "New Zealand" OR NZ OR Aotearoa) AND (ECT OR electroconvulsive) AND (ketamine OR esketamine OR psilocybin) AND (MBS OR PBS OR Pharmac OR AR-DRG OR WIES OR tariff OR "unit cost")`  
3. `("treatment-resistant depression" OR TRD) AND (ketamine OR esketamine OR psilocybin) AND (maintenance OR relapse OR durability) AND (utility OR quality of life)`  
4. `("practice guideline" OR HTA OR PBAC OR MSAC OR Pharmac) AND (ECT OR ketamine OR esketamine OR psilocybin)`  

## Screening Summary (example)
- **Records identified:** 85  
- **Duplicates removed:** 12  
- **Records screened (title/abstract):** 73  
- **Full-text assessed:** 28  
- **Included in synthesis:** 22 (5 economic models; 4 clinical trials with cost/utility; 3 HTA/policy reports; 10 costing/epi sources)

## Inclusion/Exclusion Criteria
- Include: AU/NZ CEAs, BIAs, HTAs; international analyses transferable to AU/NZ; clinical RCTs/meta-analyses informing inputs.
- Exclude: case reports; qualitative-only; non-TRD; non-comparative with ECT-relevant pathway; non-English without translation.

## Notes
- Currency year standardized to 2024 AUD/NZD; discounting per PBAC/PHARMAC; WTP thresholds AU A$45–75k, NZ contextual.
