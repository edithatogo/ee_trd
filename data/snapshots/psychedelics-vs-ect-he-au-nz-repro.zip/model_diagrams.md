# Model Diagrams (Mermaid)

## Cost-Effectiveness Model (Decision Tree + Markov)
```mermaid
flowchart LR
  A[Start: TRD Cohort] --> B{Choose Initial Tx}
  B -->|ECT| C[ECT Induction]
  B -->|Ketamine| D[Ketamine Induction]
  B -->|Esketamine| E[Esketamine Induction]
  B -->|Psilocybin| F[Psilocybin Session(s)]

  C --> C1{Remit?}
  D --> D1{Remit?}
  E --> E1{Remit?}
  F --> F1{Remit?}

  C1 -- Yes --> R[Remission State]
  D1 -- Yes --> R
  E1 -- Yes --> R
  F1 -- Yes --> R

  C1 -- No --> Dep[Depressed State]
  D1 -- No --> CECT[Cross-over to ECT]
  E1 -- No --> Dep
  F1 -- No --> CECT2[Cross-over to ECT]

  R -->|Relapse| Dep
  R -->|Maintain| R
  Dep -->|Death risk higher| X((Death))
  R --> X
```

## Budget Impact Analysis Structure
```mermaid
flowchart TB
  P[Eligible TRD patients needing ECT] --> U[Uptake assumptions (by year)]
  U --> Mix[Mix: %ECT / %Ketamine / %Psilocybin]
  Mix --> Costs[Unit cost tables (AU/NZ)]
  Costs --> Calc[Annual cost calculation]
  Calc --> Sum[Cumulative 5-year budget impact]
  Mix --> Cap[Capacity constraints (sites, staff) --> cap uptake]
```
