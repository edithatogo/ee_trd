# Psychedelics vs ECT – AU/NZ Health-Economic Package

**Date:** 2025-09-12

This bundle includes:
- `report.md` — narrative report (methods, results, tables, scenarios).
- `references.md` — reference list.
- `clinical_inputs.csv` — clinical parameters.
- `cost_inputs_au.csv`, `cost_inputs_nz.csv` — unit costs.
- `parameters_psa.csv` — base values & suggested distributions.
- `cea_model.py` — simple CEA Markov skeleton reading the CSVs.
- `bia_model.py` — simple 5-year BIA skeleton for AU/NZ.

## How to use
1. Open a terminal in this folder.
2. (Optional) Create a venv, then:
   ```bash
   python cea_model.py
   python bia_model.py
   ```
3. Edit the CSVs to localize values; enhance code for your full analysis.

> Note: The code is a **template**. For decision-grade work, expand the state space, add crossover logic, maintenance schedules, and PSA sampling. 
