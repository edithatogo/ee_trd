"""
Budget Impact Analysis (BIA) Skeleton for AU & NZ
- Reads AU/NZ cost CSVs and projects 5-year budget impact under uptake scenarios.
"""

import pandas as pd

cost_au = pd.read_csv("cost_inputs_au.csv")
cost_nz = pd.read_csv("cost_inputs_nz.csv")

def get(cost_table, item):
    row = cost_table[cost_table["Item"]==item]
    return float(row.iloc[0,1]) if not row.empty else 0.0

def bia_5y(country="AU", ect_patients=3000, uptake_ket=[0.05,0.10,0.15,0.20,0.25], uptake_psi=[0.01,0.03,0.06,0.08,0.10]):
    c = cost_au if country=="AU" else cost_nz
    # costs per patient (first year approximations)
    c_ect = get(c, "ECT total session cost (public)") * 8 if country=="AU" else get(c,"ECT session (public hospital)")*8
    c_ket = get(c, "Ketamine total session (IV)") * 12  # induction + early maintenance approx
    c_psi = get(c, "Psilocybin program (2-dose + therapy)")

    results = []
    for year in range(5):
        ket_share = uptake_ket[year]
        psi_share = uptake_psi[year]
        ect_share = 1 - ket_share - psi_share
        ect_n = int(ect_patients * ect_share)
        ket_n = int(ect_patients * ket_share)
        psi_n = int(ect_patients * psi_share)
        # Baseline: all ect
        baseline = ect_patients * c_ect
        new = ect_n * c_ect + ket_n * c_ket + psi_n * c_psi
        results.append({"year":year+1,"baseline_cost":baseline,"scenario_cost":new,"net_impact":new-baseline,
                        "ECT_patients":ect_n,"Ket_patients":ket_n,"Psi_patients":psi_n})
    return pd.DataFrame(results)

if __name__=="__main__":
    df_au = bia_5y("AU")
    df_nz = bia_5y("NZ", ect_patients=300)
    print("AU BIA:\n", df_au)
    print("\nNZ BIA:\n", df_nz)
