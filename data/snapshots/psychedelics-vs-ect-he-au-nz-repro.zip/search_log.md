# Search Log – Psychedelics vs ECT (AU/NZ HEOR)

**Date completed:** 12 Sep 2025

## Databases Queried
- MEDLINE/PubMed
- Embase
- PsycINFO
- EconLit
- Cochrane CENTRAL
- Scopus
- Web of Science
- medRxiv, SSRN
- ISPOR abstract library

## Grey Literature & Policy
- PBAC/MSAC Public Summary Documents (Australia)
- PHARMAC/PTAC minutes (New Zealand)
- IHPA/NHCDC, AR-DRG (Australia)
- WIESNZ/NMDS (New Zealand)
- AIHW reports
- Te Whatu Ora pricing data
- MBS/PBS schedules (Australia)
- Pharmac schedule (NZ)
- TGA & Medsafe guidance

## Example Search Strings (PubMed)
1. `(ketamine OR esketamine OR psilocybin OR "psychedelic-assisted") AND (ECT OR electroconvulsive) AND (cost* OR economic OR cost-effectiveness OR ICER OR QALY)`
2. `(Australia OR "New Zealand" OR NZ OR Aotearoa) AND (ECT OR electroconvulsive) AND (ketamine OR esketamine OR psilocybin) AND (MBS OR PBS OR Pharmac OR AR-DRG OR WIES OR tariff OR "unit cost")`
3. `("treatment-resistant depression" OR TRD) AND (ketamine OR esketamine OR psilocybin) AND (maintenance OR relapse OR durability) AND (utility OR quality of life)`

## Screening
- Records retrieved (all sources): ~480
- Records screened (titles/abstracts): ~230
- Full-text assessed: ~65
- Included for HEOR extraction: 18
- Included for AU/NZ parameterisation only: 12 (policy docs, schedules)
