# References (Selected & Cited)
(Expanded list matching items in the report; add DOIs/URLs as needed)
1. Anand A, et al. NEJM 2023 — Ketamine vs ECT in non-psychotic TRD.
2. Frederiksen SO, et al. BMC Psychiatry 2021 — Esketamine vs ECT cost-utility.
3. Chatterton ML, et al. J Affect Disord 2025 — KADS economic evaluation.
4. PBAC PSDs 2021–2024 — Esketamine resubmissions.
5. PHARMAC PTAC 2020 — Esketamine.
6. ICER US — Esketamine report.
7. UNSW News 2023 — Ketamine access & costs.
8. RNZ 2025 — Psilocybin prescriber; costs.
9. Guardian 2024 — Psychedelic therapy clinic costs.
10. SUSTAIN/TRANSFORM trials — Esketamine maintenance & induction.
