# Health-Economic Case for Substituting Psychedelics for ECT (Australia & New Zealand)

**Date:** 12 Sep 2025 (AEST)  
**Perspectives:** Health system (primary), Patient & Societal (secondary)  
**Standards:** CHEERS 2022; ISPOR BIA Good Practice; PBAC/MSAC (AU) & PHARMAC (NZ) economic norms  

(Condensed report body — see chat for full narrative.)
