# Psychedelics vs ECT – AU/NZ Health-Economic Package
**Date:** 2025-09-12

Contents:
- report.md, references.md
- clinical_inputs.csv, cost_inputs_au.csv, cost_inputs_nz.csv
- parameters_psa.csv
- cea_model.py, bia_model.py

See reproducibility add-ons and extras below.
